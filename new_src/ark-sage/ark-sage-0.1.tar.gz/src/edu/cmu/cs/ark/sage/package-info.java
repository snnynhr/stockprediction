/**
 * Main class for implementation of {@link edu.cmu.cs.ark.sage.SAGE}.
 * 
 * @author Yanchuan Sim
 * @version 0.1
 */
package edu.cmu.cs.ark.sage;

