/**
 * A collection of custom types made by yc.
 * 
 * @author Yanchuan Sim
 * @version 0.1
 */
package edu.cmu.cs.ark.yc.utils.types;

