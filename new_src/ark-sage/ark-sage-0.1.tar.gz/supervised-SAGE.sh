#!/bin/sh

# JAVA=/usr/java/latest/bin/java
JAVA=`which java`

$JAVA -XX:ParallelGCThreads=2 -cp ark-sage-0.1.jar:stanford-classifier.jar:commons-math3-3.1.1.jar:trove-3.0.3.jar:yc-config-0.2.jar edu.cmu.cs.ark.sage.apps.SupervisedSAGE $@
